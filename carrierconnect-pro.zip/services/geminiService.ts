
import { GoogleGenAI } from "@google/genai";
import { CarrierData, ShipperData } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeProfile = async (type: 'carrier' | 'shipper', data: any) => {
  const prompt = type === 'carrier' 
    ? `Analyze this carrier profile for potential risks:
      - DOT: ${data.dotNumber}
      - MC: ${data.mcNumber}
      - Authority Date: ${data.authorityDate}
      - Name: ${data.legalName}
      Focus on compliance requirements (1yr+ authority). Respond in one professional paragraph.`
    : `Analyze this potential shipper profile for credit/reliability assessment:
      - Company: ${data.legalName}
      - Commodity: ${data.commodityType}
      - Monthly Volume: ${data.monthlyVolume}
      Focus on typical shipping patterns and potential cargo insurance needs. Respond in one professional paragraph.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    return "Verification services currently unavailable, but manual override is active.";
  }
};
