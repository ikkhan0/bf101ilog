
export type UserType = 'carrier' | 'shipper' | null;

export interface CarrierData {
  dotNumber: string;
  mcNumber: string;
  legalName: string;
  dbaName: string;
  authorityDate: string;
  ein: string;
  address: string;
  city: string;
  state: string;
  zip: string;
  contactName: string;
  contactEmail: string;
  contactPhone: string;
  equipmentTypes: string[];
  preferredLanes: string[];
}

export interface ShipperData {
  legalName: string;
  dbaName: string;
  ein: string;
  address: string;
  city: string;
  state: string;
  zip: string;
  contactName: string;
  contactEmail: string;
  contactPhone: string;
  commodityType: string;
  monthlyVolume: string;
  averageValue: string;
  preferredEquipment: string[];
}

export enum OnboardingStep {
  Selection = -1,
  Verification = 0, // Carrier only
  CompanyProfile = 1,
  Operations = 2, // Shipments for Shippers
  Documentation = 3,
  Agreement = 4,
  Complete = 5
}
