
import React from 'react';
import { OnboardingStep, UserType } from '../types';

interface StepIndicatorProps {
  currentStep: OnboardingStep;
  userType: UserType;
}

export const StepIndicator: React.FC<StepIndicatorProps> = ({ currentStep, userType }) => {
  const carrierSteps = [
    { id: OnboardingStep.Verification, title: 'Verification', icon: 'fa-id-card' },
    { id: OnboardingStep.CompanyProfile, title: 'Company Details', icon: 'fa-building' },
    { id: OnboardingStep.Operations, title: 'Operations', icon: 'fa-truck' },
    { id: OnboardingStep.Documentation, title: 'Documents', icon: 'fa-file-shield' },
    { id: OnboardingStep.Agreement, title: 'Agreement', icon: 'fa-signature' },
  ];

  const shipperSteps = [
    { id: OnboardingStep.CompanyProfile, title: 'Company Details', icon: 'fa-building' },
    { id: OnboardingStep.Operations, title: 'Shipments', icon: 'fa-box-open' },
    { id: OnboardingStep.Documentation, title: 'Legal & Tax', icon: 'fa-file-shield' },
    { id: OnboardingStep.Agreement, title: 'Agreement', icon: 'fa-signature' },
  ];

  const steps = userType === 'carrier' ? carrierSteps : shipperSteps;

  return (
    <div className="mb-12 overflow-x-auto pb-4">
      <div className="flex items-center justify-between min-w-[600px] md:min-w-0">
        {steps.map((step, idx) => {
          const isActive = currentStep === step.id;
          const isCompleted = currentStep > step.id;
          
          return (
            <React.Fragment key={step.id}>
              <div className="flex flex-col items-center relative z-10">
                <div 
                  className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 border-2 
                    ${isCompleted ? 'bg-green-500 border-green-500 text-white' : 
                      isActive ? 'bg-blue-600 border-blue-600 text-white' : 
                      'bg-white border-gray-300 text-gray-400'}`}
                >
                  {isCompleted ? (
                    <i className="fa-solid fa-check"></i>
                  ) : (
                    <i className={`fa-solid ${step.icon}`}></i>
                  )}
                </div>
                <span className={`mt-2 text-xs font-bold whitespace-nowrap ${isActive ? 'text-blue-600' : 'text-gray-500'}`}>
                  {step.title}
                </span>
              </div>
              {idx < steps.length - 1 && (
                <div className="flex-grow h-[2px] mx-4 bg-gray-200">
                  <div 
                    className="h-full bg-green-500 transition-all duration-500" 
                    style={{ width: isCompleted ? '100%' : '0%' }}
                  />
                </div>
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
};
