
import React, { useState } from 'react';
import { Layout } from './components/Layout';
import { StepIndicator } from './components/StepIndicator';
import { CarrierData, ShipperData, OnboardingStep, UserType } from './types';
import { analyzeProfile } from './services/geminiService';

const INITIAL_CARRIER_DATA: CarrierData = {
  dotNumber: '', mcNumber: '', legalName: '', dbaName: '', authorityDate: '',
  ein: '', address: '', city: '', state: '', zip: '',
  contactName: '', contactEmail: '', contactPhone: '',
  equipmentTypes: [], preferredLanes: []
};

const INITIAL_SHIPPER_DATA: ShipperData = {
  legalName: '', dbaName: '', ein: '', address: '', city: '', state: '', zip: '',
  contactName: '', contactEmail: '', contactPhone: '',
  commodityType: '', monthlyVolume: '', averageValue: '', preferredEquipment: []
};

const App: React.FC = () => {
  const [userType, setUserType] = useState<UserType>(null);
  const [currentStep, setCurrentStep] = useState<OnboardingStep>(OnboardingStep.Selection);
  const [carrierData, setCarrierData] = useState<CarrierData>(INITIAL_CARRIER_DATA);
  const [shipperData, setShipperData] = useState<ShipperData>(INITIAL_SHIPPER_DATA);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<string>('');

  const nextStep = () => setCurrentStep(prev => prev + 1);
  const prevStep = () => {
    if (currentStep === OnboardingStep.CompanyProfile && userType === 'shipper') {
      setCurrentStep(OnboardingStep.Selection);
      setUserType(null);
    } else if (currentStep === OnboardingStep.Verification && userType === 'carrier') {
      setCurrentStep(OnboardingStep.Selection);
      setUserType(null);
    } else {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    if (userType === 'carrier') {
      setCarrierData(prev => ({ ...prev, [name]: value }));
    } else {
      setShipperData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleRoleSelection = (role: UserType) => {
    setUserType(role);
    setCurrentStep(role === 'carrier' ? OnboardingStep.Verification : OnboardingStep.CompanyProfile);
  };

  const handleCarrierVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!carrierData.authorityDate) {
      setError("Authority grant date is required.");
      return;
    }
    const authDate = new Date(carrierData.authorityDate);
    const oneYearAgo = new Date();
    oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);

    if (authDate > oneYearAgo) {
      setError("Compliance Notice: Our automated onboarding requires 1 year of active authority. New carriers must proceed via manual review.");
      // For this demo, let's just show error but allow proceed if we wanted to mimic manual override.
      return;
    }
    setLoading(true);
    const analysis = await analyzeProfile('carrier', carrierData);
    setAiAnalysis(analysis || '');
    setLoading(false);
    nextStep();
  };

  const handleShipperNext = async () => {
    setLoading(true);
    const analysis = await analyzeProfile('shipper', shipperData);
    setAiAnalysis(analysis || '');
    setLoading(false);
    nextStep();
  };

  const renderStep = () => {
    switch (currentStep) {
      case OnboardingStep.Selection:
        return (
          <div className="max-w-4xl mx-auto w-full text-center py-12">
            <h1 className="text-4xl font-extrabold text-gray-900 mb-4">Welcome to FreightConnect</h1>
            <p className="text-xl text-gray-500 mb-12">Choose your path to begin the professional onboarding process.</p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <button 
                onClick={() => handleRoleSelection('carrier')}
                className="group bg-white p-10 rounded-2xl shadow-xl border-2 border-transparent hover:border-blue-500 transition-all text-left"
              >
                <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center text-blue-600 text-3xl mb-6 group-hover:scale-110 transition-transform">
                  <i className="fa-solid fa-truck"></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">Carrier Portal</h3>
                <p className="text-gray-500">For owner-operators and fleet owners looking to join our network.</p>
                <div className="mt-8 flex items-center text-blue-600 font-bold">
                  Start Carrier Onboarding <i className="fa-solid fa-arrow-right ml-2 group-hover:translate-x-2 transition-transform"></i>
                </div>
              </button>

              <button 
                onClick={() => handleRoleSelection('shipper')}
                className="group bg-white p-10 rounded-2xl shadow-xl border-2 border-transparent hover:border-green-500 transition-all text-left"
              >
                <div className="w-16 h-16 bg-green-100 rounded-2xl flex items-center justify-center text-green-600 text-3xl mb-6 group-hover:scale-110 transition-transform">
                  <i className="fa-solid fa-box"></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">Shipper Portal</h3>
                <p className="text-gray-500">For manufacturers and distributors needing reliable transport solutions.</p>
                <div className="mt-8 flex items-center text-green-600 font-bold">
                  Start Shipper Onboarding <i className="fa-solid fa-arrow-right ml-2 group-hover:translate-x-2 transition-transform"></i>
                </div>
              </button>
            </div>
          </div>
        );

      case OnboardingStep.Verification: // Carrier Only
        return (
          <div className="bg-white rounded-xl shadow-sm p-8 border border-gray-100 max-w-2xl mx-auto w-full">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Motor Carrier Verification</h2>
            <form onSubmit={handleCarrierVerify} className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-bold text-gray-600 mb-2">DOT #</label>
                  <input required name="dotNumber" value={carrierData.dotNumber} onChange={handleInputChange} className="w-full px-4 py-2 border rounded-lg" placeholder="1234567" />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-600 mb-2">MC #</label>
                  <input required name="mcNumber" value={carrierData.mcNumber} onChange={handleInputChange} className="w-full px-4 py-2 border rounded-lg" placeholder="123456" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-600 mb-2">Authority Date</label>
                <input required type="date" name="authorityDate" value={carrierData.authorityDate} onChange={handleInputChange} className="w-full px-4 py-2 border rounded-lg" />
              </div>
              {error && <div className="p-4 bg-red-50 text-red-700 rounded-lg text-sm border-l-4 border-red-500">{error}</div>}
              <div className="flex justify-between pt-6">
                <button type="button" onClick={prevStep} className="text-gray-500">Back</button>
                <button type="submit" disabled={loading} className="px-8 py-3 bg-blue-600 text-white rounded-lg font-bold shadow-lg shadow-blue-200">
                  {loading ? <i className="fa-solid fa-spinner fa-spin mr-2"></i> : 'Verify & Continue'}
                </button>
              </div>
            </form>
          </div>
        );

      case OnboardingStep.CompanyProfile:
        const data = userType === 'carrier' ? carrierData : shipperData;
        return (
          <div className="bg-white rounded-xl shadow-sm p-8 border border-gray-100 w-full max-w-4xl mx-auto">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Company Information</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-bold text-gray-600 mb-1">Legal Entity Name</label>
                  <input name="legalName" value={data.legalName} onChange={handleInputChange} className="w-full px-4 py-2 border rounded-lg" />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-600 mb-1">Tax ID / EIN</label>
                  <input name="ein" value={data.ein} onChange={handleInputChange} className="w-full px-4 py-2 border rounded-lg" />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-600 mb-1">Contact Email</label>
                  <input name="contactEmail" value={data.contactEmail} onChange={handleInputChange} className="w-full px-4 py-2 border rounded-lg" />
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-bold text-gray-600 mb-1">Primary Address</label>
                  <input name="address" value={data.address} onChange={handleInputChange} className="w-full px-4 py-2 border rounded-lg" />
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <div className="col-span-1"><input name="city" value={data.city} onChange={handleInputChange} className="w-full px-4 py-2 border rounded-lg" placeholder="City" /></div>
                  <div><input name="state" value={data.state} onChange={handleInputChange} className="w-full px-4 py-2 border rounded-lg" placeholder="ST" /></div>
                  <div><input name="zip" value={data.zip} onChange={handleInputChange} className="w-full px-4 py-2 border rounded-lg" placeholder="Zip" /></div>
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-600 mb-1">Phone Number</label>
                  <input name="contactPhone" value={data.contactPhone} onChange={handleInputChange} className="w-full px-4 py-2 border rounded-lg" />
                </div>
              </div>
            </div>
            <div className="flex justify-between mt-10">
              <button onClick={prevStep} className="text-gray-500 font-medium">Back</button>
              <button onClick={nextStep} className="px-10 py-3 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-all">Next: Operations</button>
            </div>
          </div>
        );

      case OnboardingStep.Operations:
        if (userType === 'carrier') {
          return (
            <div className="bg-white rounded-xl shadow-sm p-8 border border-gray-100 w-full max-w-4xl mx-auto">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Carrier Operations</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <label className="block text-sm font-bold text-gray-600 mb-4">Equipment & Capabilities</label>
                  <div className="space-y-2">
                    {['Dry Van', 'Reefer', 'Flatbed', 'Intermodal'].map(eq => (
                      <label key={eq} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-blue-50">
                        <input type="checkbox" /> <span className="text-sm font-medium">{eq}</span>
                      </label>
                    ))}
                  </div>
                </div>
                <div>
                  <h4 className="text-sm font-bold text-blue-600 mb-2 uppercase tracking-wide">AI Safety Profile</h4>
                  <div className="bg-blue-50 p-4 rounded-xl border border-blue-100 italic text-sm text-blue-800">
                    <i className="fa-solid fa-robot mr-2"></i> {aiAnalysis || "Pending data check..."}
                  </div>
                </div>
              </div>
              <div className="flex justify-between mt-10">
                <button onClick={prevStep} className="text-gray-500">Back</button>
                <button onClick={nextStep} className="px-10 py-3 bg-blue-600 text-white rounded-xl font-bold">Documentation</button>
              </div>
            </div>
          );
        } else {
          return (
            <div className="bg-white rounded-xl shadow-sm p-8 border border-gray-100 w-full max-w-4xl mx-auto">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Shipment Profiles</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-bold text-gray-600 mb-1">Primary Commodities</label>
                    <input name="commodityType" value={shipperData.commodityType} onChange={handleInputChange} className="w-full px-4 py-2 border rounded-lg" placeholder="e.g. Produce, Electronics, Lumber" />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-600 mb-1">Average Shipments / Month</label>
                    <select name="monthlyVolume" value={shipperData.monthlyVolume} onChange={handleInputChange} className="w-full px-4 py-2 border rounded-lg">
                      <option value="">Select Range</option>
                      <option>1-10</option>
                      <option>11-50</option>
                      <option>51-200</option>
                      <option>200+</option>
                    </select>
                  </div>
                </div>
                <div>
                   <h4 className="text-sm font-bold text-green-600 mb-2 uppercase tracking-wide">AI Industry Analysis</h4>
                   <div className="bg-green-50 p-4 rounded-xl border border-green-100 italic text-sm text-green-800">
                    <i className="fa-solid fa-magnifying-glass-chart mr-2"></i> {aiAnalysis || "Evaluating market segment..."}
                  </div>
                </div>
              </div>
              <div className="flex justify-between mt-10">
                <button onClick={prevStep} className="text-gray-500">Back</button>
                <button onClick={nextStep} className="px-10 py-3 bg-green-600 text-white rounded-xl font-bold">Documentation</button>
              </div>
            </div>
          );
        }

      case OnboardingStep.Documentation:
        const docs = userType === 'carrier' 
          ? ['W-9 Form', 'Active COI', 'MC Authority Letter']
          : ['W-9 Form', 'Credit Application', 'Signed Shipping Agreement'];
        return (
          <div className="bg-white rounded-xl shadow-sm p-8 border border-gray-100 w-full max-w-2xl mx-auto">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Upload Documents</h2>
            <div className="space-y-4">
              {docs.map(doc => (
                <div key={doc} className="p-4 border border-dashed border-gray-300 rounded-xl flex items-center justify-between hover:bg-gray-50">
                  <span className="font-bold text-gray-700">{doc}</span>
                  <button className="text-blue-600 text-sm font-bold"><i className="fa-solid fa-cloud-arrow-up mr-2"></i> Upload</button>
                </div>
              ))}
            </div>
            <div className="flex justify-between mt-10">
              <button onClick={prevStep} className="text-gray-500">Back</button>
              <button onClick={nextStep} className="px-10 py-3 bg-blue-600 text-white rounded-xl font-bold">Final Agreement</button>
            </div>
          </div>
        );

      case OnboardingStep.Agreement:
        return (
          <div className="bg-white rounded-xl shadow-sm p-8 border border-gray-100 w-full max-w-3xl mx-auto">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Terms & Conditions</h2>
            <div className="bg-gray-50 p-6 rounded-xl h-48 overflow-y-auto text-xs text-gray-600 mb-6 font-mono border">
              BY SIGNING THIS AGREEMENT, THE UNDERSIGNED ENTITY ("REGISTERED PARTY") AGREES TO THE BROKER-CARRIER-SHIPPER PROTOCOLS...
              (Standard legal jargon about payment terms, liability, and safety requirements).
              For {userType === 'carrier' ? 'Carriers' : 'Shippers'}, specific clauses regarding {userType === 'carrier' ? 'detention and insurance' : 'credit limits and payment cycles'} apply.
            </div>
            <div className="space-y-6">
              <label className="flex items-center space-x-3 cursor-pointer">
                <input type="checkbox" className="w-5 h-5" />
                <span className="text-sm font-medium">I agree to the Terms of Service and Compliance Standards.</span>
              </label>
              <div>
                <label className="block text-xs font-bold text-gray-400 mb-2 uppercase">Digital Signature</label>
                <input placeholder="Type your full legal name" className="w-full px-4 py-4 border bg-gray-50 rounded-lg text-xl italic font-serif" />
              </div>
            </div>
            <div className="flex justify-between mt-10">
              <button onClick={prevStep} className="text-gray-500">Back</button>
              <button onClick={() => setCurrentStep(OnboardingStep.Complete)} className={`px-12 py-4 text-white rounded-xl font-bold shadow-xl transition-all ${userType === 'carrier' ? 'bg-blue-600 shadow-blue-200' : 'bg-green-600 shadow-green-200'}`}>Complete Onboarding</button>
            </div>
          </div>
        );

      case OnboardingStep.Complete:
        return (
          <div className="text-center py-12 max-w-md mx-auto">
            <div className={`w-24 h-24 rounded-full flex items-center justify-center text-5xl mx-auto mb-8 ${userType === 'carrier' ? 'bg-blue-100 text-blue-600' : 'bg-green-100 text-green-600'}`}>
              <i className="fa-solid fa-circle-check"></i>
            </div>
            <h2 className="text-3xl font-extrabold text-gray-900 mb-4">Registration Sent!</h2>
            <p className="text-gray-500 mb-10 leading-relaxed">
              Our compliance team will review your {userType} application and reach out within one business day.
            </p>
            <button onClick={() => window.location.reload()} className="w-full py-4 bg-gray-900 text-white font-bold rounded-2xl hover:scale-[1.02] transition-transform">Back to Start</button>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <Layout>
      {currentStep !== OnboardingStep.Selection && currentStep !== OnboardingStep.Complete && (
        <div className="max-w-4xl mx-auto w-full">
          <StepIndicator currentStep={currentStep} userType={userType} />
        </div>
      )}
      <div className="flex-grow flex items-center justify-center px-4">
        {renderStep()}
      </div>
    </Layout>
  );
};

export default App;
